package hospital_management.auth_service.config;

public class JwtAuthFilter {
}
