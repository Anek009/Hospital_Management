package hospital_management.auth_service.entity;

public enum Role {
    DOCTOR, PATIENT, STAFF, ADMIN, VISITOR
}

