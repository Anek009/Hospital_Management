package hospital_management.hospital_service.entity;

public class Hospital {
}
