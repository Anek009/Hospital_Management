package hospital_management.medical_reports;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalReportsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalReportsApplication.class, args);
	}

}
