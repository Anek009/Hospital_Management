package hospital_management.medical_reports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalReportsApplicationTests {

	@Test
	void contextLoads() {
	}

}
